#include "threads/thread.h"
#include <debug.h>
#include <stddef.h>
#include <random.h>
#include <stdio.h>
#include <string.h>
#include "threads/flags.h"
#include "threads/interrupt.h"
#include "threads/intr-stubs.h"
#include "threads/palloc.h"
#include "threads/switch.h"
#include "threads/synch.h"
#include "threads/vaddr.h"
#ifdef USERPROG
#include "userprog/process.h"
#endif

/* Random value for struct thread's `magic' member.
   Used to detect stack overflow.  See the big comment at the top
   of thread.h for details. */
#define THREAD_MAGIC 0xcd6abf4b
fixed_t load_avg;
extern bool is_hierarchy;
/* List of processes in THREAD_READY state, that is, processes
   that are ready to run but not actually running. */
static struct list new_ready_list;

/* List of all processes.  Processes are added to this list
   when they are first scheduled and removed when they exit. */
static struct list all_list;

/* Idle thread. */
static struct thread* idle_thread;

/* Initial thread, the thread running init.c:main(). */
static struct thread* initial_thread;

/* Lock used by allocate_tid(). */
static struct lock tid_lock;

/* Stack frame for kernel_thread(). */
struct kernel_thread_frame {
  void* eip;             /* Return address. */
  thread_func* function; /* Function to call. */
  void* aux;             /* Auxiliary data for function. */
};

/* Scheduling. */
#define TIME_SLICE 4 /* # of timer ticks to give each thread. */
bool thread_mlfqs;
static unsigned thread_ticks; /* # of timer ticks since last yield. */
static void init_thread(struct thread*, const char* name, int priority);
static void schedule(void);
static void thread_enqueue(struct thread* t);
static tid_t allocate_tid(void);
static bool is_thread(struct thread*) UNUSED;
static void* alloc_frame(struct thread*, size_t size);
void thread_switch_tail(struct thread* prev);
static void kernel_thread(thread_func*, void* aux);
static void idle(void* aux UNUSED);
static struct thread* running_thread(void);
static struct thread* next_thread_to_run(void);
static struct thread* thread_schedule_fifo(void);
static struct thread* thread_schedule_prio(void);
static struct thread* thread_schedule_fair(void);
static struct thread* thread_schedule_mlfqs(void);
static struct thread* thread_schedule_reserved(void);
bool begin_schedule;
/* Statistics. */
static long long user_ticks;   /* # of timer ticks in user programs. */
static long long idle_ticks;   /* # of timer ticks spent idle. */
static long long kernel_ticks; /* # of timer ticks in kernel threads. */

/* Initializes the threading system by transforming the code
   that's currently running into a thread.  This can't work in
   general and it is possible in this case only because loader.S
   was careful to put the bottom of the stack at a page boundary.

   Also initializes the run queue and the tid lock.

   After calling this function, be sure to initialize the page
   allocator before trying to create any threads with
   thread_create().

   It is not safe to call thread_current() until this function
   finishes. */
void thread_init(void) {
  ASSERT(intr_get_level() == INTR_OFF);

  lock_init(&tid_lock);
  list_init(&new_ready_list);
  list_init(&all_list);

  /* Set up a thread structure for the running thread. */
  initial_thread = running_thread();
  init_thread(initial_thread, "main", PRI_DEFAULT);
  initial_thread->status = THREAD_RUNNING;
  initial_thread->tid = allocate_tid();
}

/*在每个定时器计时时由定时器中断处理程序调用。
因此，此函数在外部中断上下文中运行。*/
void thread_tick(void) {
  struct thread* t = thread_current();

  /* Update statistics. */
  if (t == idle_thread)
    idle_ticks++;
#ifdef USERPROG
  else if (t->pcb != NULL)
    user_ticks++;
#endif
  else
    kernel_ticks++;

  /* Enforce preemption. */
  if (++thread_ticks >= TIME_SLICE)
    intr_yield_on_return();
}

enum sched_policy active_sched_policy;

typedef struct thread* scheduler_func(void);

scheduler_func* scheduler_jump_table[8] = {thread_schedule_fifo,     thread_schedule_prio,
                                           thread_schedule_fair,     thread_schedule_mlfqs,
                                           thread_schedule_reserved, thread_schedule_reserved,
                                           thread_schedule_reserved, thread_schedule_reserved};

/* Prints thread statistics. */
void thread_print_stats(void) {
  printf("Thread: %lld idle ticks, %lld kernel ticks, %lld user ticks\n", idle_ticks, kernel_ticks,
         user_ticks);
}

/* Creates a new kernel thread named NAME with the given initial
   PRIORITY, which executes FUNCTION passing AUX as the argument,
   and adds it to the ready queue.  Returns the thread identifier
   for the new thread, or TID_ERROR if creation fails.

   If thread_start() has been called, then the new thread may be
   scheduled before thread_create() returns.  It could even exit
   before thread_create() returns.  Contrariwise, the original
   thread may run for any amount of time before the new thread is
   scheduled.  Use a semaphore or some other form of
   synchronization if you need to ensure ordering.

   The code provided sets the new thread's `priority' member to
   PRIORITY, but no actual priority scheduling is implemented.
   Priority scheduling is the goal of Problem 1-3. */
tid_t thread_create(const char* name, int priority, thread_func* function, void* aux) {
  struct thread* t;
  struct kernel_thread_frame* kf;
  struct switch_entry_frame* ef;
  struct switch_threads_frame* sf;
  tid_t tid;

  ASSERT(function != NULL);

  /* Allocate thread. */
  t = palloc_get_page(PAL_ZERO);
  if (t == NULL)
    return TID_ERROR;

  /* Initialize thread. */
  init_thread(t, name, priority);
  tid = t->tid = allocate_tid();
  t->thread_sleepticks = 0; //初始化为0

  /* Stack frame for kernel_thread(). */
  kf = alloc_frame(t, sizeof *kf);
  kf->eip = NULL;
  kf->function = function;
  kf->aux = aux;

  /* Stack frame for switch_entry(). */
  ef = alloc_frame(t, sizeof *ef);
  ef->eip = (void (*)(void))kernel_thread;

  /* Stack frame for switch_threads(). */
  sf = alloc_frame(t, sizeof *sf);
  sf->eip = switch_entry;
  sf->ebp = 0;

  /* Add to run queue. */
  thread_unblock(t);
  //if current 进程优先级小于新进程，把当前运行进程放入就绪队列
  if (thread_current()->priority < priority) {
    thread_yield();
  }
  return tid;
}

/*通过启用中断来启动抢占式线程调度。还创建了空闲线程。*/
void thread_start(void) {
  /* Create the idle thread. */
  struct semaphore idle_started;
  load_avg = FP_CONST(0);
  begin_schedule = true;
  sema_init(&idle_started, 0);
  thread_create("idle", PRI_MIN, idle, &idle_started);

  /* Start preemptive thread scheduling. */
  intr_enable();

  /* Wait for the idle thread to initialize idle_thread. */
  sema_down(&idle_started);
}

static void thread_enqueue(struct thread* t) {
  ASSERT(intr_get_level() == INTR_OFF);
  ASSERT(is_thread(t));

  if (active_sched_policy == SCHED_FIFO)
    list_push_back(&new_ready_list, &t->elem);
  else if (active_sched_policy == SCHED_PRIO)
    list_push_back(&new_ready_list, &t->elem);
  else if (active_sched_policy == SCHED_FAIR)
    list_push_back(&new_ready_list, &t->elem);
  else if (active_sched_policy == SCHED_MLFQS)
    list_push_back(&new_ready_list, &t->elem);
  else
    PANIC("Unimplemented scheduling policy value: %d", active_sched_policy);
}

//阻塞进程
void thread_block(void) {
  ASSERT(!intr_context());
  ASSERT(intr_get_level() == INTR_OFF);

  thread_current()->status = THREAD_BLOCKED;
  schedule();
}

/*返回正在运行线程名称。*/
const char* thread_name(void) { return thread_current()->name; }

struct thread* thread_current(void) {
  struct thread* t = running_thread();
  ASSERT(is_thread(t));
  ASSERT(t->status == THREAD_RUNNING);

  return t;
}

void thread_exit(void) {
  ASSERT(!intr_context());
  intr_disable();
  list_remove(&thread_current()->allelem);
  thread_current()->status = THREAD_DYING;
  schedule();
  NOT_REACHED();
}

/*返回正在运行的线程的 tid*/
tid_t thread_tid(void) { return thread_current()->tid; }

/*释放 CPU*/
void thread_yield(void) {
  if (!begin_schedule) {
    return;
  }
  struct thread* cur = thread_current();
  enum intr_level old_level;

  ASSERT(!intr_context());

  old_level = intr_disable();
  if (cur != idle_thread)
    list_insert_ordered(&new_ready_list, &cur->elem, (list_less_func*)&compare_thread_priority,
                        NULL);
  cur->status = THREAD_READY;
  schedule();
  intr_set_level(old_level);
}

/*在所有线程上调用函数 'func'，并传递 'aux'。此函数必须在中断关闭的情况下调用。*/
void thread_foreach(thread_action_func* func, void* aux) {
  struct list_elem* e;

  ASSERT(intr_get_level() == INTR_OFF);

  for (e = list_begin(&all_list); e != list_end(&all_list); e = list_next(e)) {
    struct thread* t = list_entry(e, struct thread, allelem);
    func(t, aux);
  }
}

/*返回当前线程的nice值*/
int thread_get_nice(void) {
  /* Not yet implemented. */
  return thread_current()->nice;
}

/*将当前线程的优先级设置为 NEW_ PRIORITY。*/
void thread_set_priority(int new_priority) {
  if (active_sched_policy == SCHED_FAIR)
    return;

  enum intr_level old_level = intr_disable();

  struct thread* current_thread = thread_current();
  int old_priority = current_thread->priority;
  current_thread->original_priority = new_priority;

  if (list_empty(&current_thread->locks) || new_priority > old_priority) {
    current_thread->priority = new_priority;
    thread_yield();
  }

  intr_set_level(old_level);
}

/* Transitions a blocked thread T to the ready-to-run state.
   This is an error if T is not blocked.  (Use thread_yield() to
   make the running thread ready.)

   This function does not preempt the running thread.  This can
   be important: if the caller had disabled interrupts itself,
   it may expect that it can atomically unblock a thread and
   update other data. */
void thread_unblock(struct thread* t) {
  enum intr_level old_level;

  ASSERT(is_thread(t));

  old_level = intr_disable();
  ASSERT(t->status == THREAD_BLOCKED);
  list_insert_ordered(&new_ready_list, &t->elem, (list_less_func*)&compare_thread_priority, NULL);
  //thread_enqueue(t);
  t->status = THREAD_READY;
  intr_set_level(old_level);
}

/*返回当前线程的优先级*/
int thread_get_priority(void) { return thread_current()->priority; }

/*将当前线程的nice值设置为NICE */
void thread_set_nice(int nice UNUSED) { /* Not yet implemented. */
  thread_current()->nice = nice;

  mlfqs_update_priority(thread_current());

  thread_yield();
}

/*返回系统负载平均值的 100 倍*/
int thread_get_load_avg(void) {
  /* Not yet implemented. */
  return FP_ROUND(FP_MULT_MIX(load_avg, 100));
}

/*返回当前线程 recent_cpu 值的 100 倍*/
int thread_get_recent_cpu(void) {
  /* Not yet implemented. */
  return FP_ROUND(FP_MULT_MIX(thread_current()->recent_cpu, 100));
}

/*如果 T 似乎指向一个有效的线程，则返回 true*/
static bool is_thread(struct thread* t) { return t != NULL && t->magic == THREAD_MAGIC; }

/* Idle thread.  Executes when no other thread is ready to run.

   The idle thread is initially put on the ready list by
   thread_start().  It will be scheduled once initially, at which
   point it initializes idle_thread, "up"s the semaphore passed
   to it to enable thread_start() to continue, and immediately
   blocks.  After that, the idle thread never appears in the
   ready list.  It is returned by next_thread_to_run() as a
   special case when the ready list is empty. */
static void idle(void* idle_started_ UNUSED) {
  struct semaphore* idle_started = idle_started_;
  idle_thread = thread_current();
  sema_up(idle_started);

  for (;;) {
    /* Let someone else run. */
    intr_disable();
    thread_block();

    /* Re-enable interrupts and wait for the next one.

         The `sti' instruction disables interrupts until the
         completion of the next instruction, so these two
         instructions are executed atomically.  This atomicity is
         important; otherwise, an interrupt could be handled
         between re-enabling interrupts and waiting for the next
         one to occur, wasting as much as one clock tick worth of
         time.

         See [IA32-v2a] "HLT", [IA32-v2b] "STI", and [IA32-v3a]
         7.11.1 "HLT Instruction". */
    asm volatile("sti; hlt" : : : "memory");
  }
}

/*用作内核线程基础的函数*/
static void kernel_thread(thread_func* function, void* aux) {
  ASSERT(function != NULL);

  intr_enable(); /* The scheduler runs with interrupts off. */
  function(aux); /* Execute the thread function. */
  thread_exit(); /* If function() returns, kill the thread. */
}

/*返回正在运行的线程*/
struct thread* running_thread(void) {
  uint32_t* esp;

  /* Copy the CPU's stack pointer into `esp', and then round that
     down to the start of a page.  Because `struct thread' is
     always at the beginning of a page and the stack pointer is
     somewhere in the middle, this locates the curent thread. */
  asm("mov %%esp, %0" : "=g"(esp));
  return pg_round_down(esp);
}

static void init_thread(struct thread* t, const char* name, int priority) {
  enum intr_level old_level;

  ASSERT(t != NULL);
  ASSERT(PRI_MIN <= priority && priority <= PRI_MAX);
  ASSERT(name != NULL);

  memset(t, 0, sizeof *t);
  t->status = THREAD_BLOCKED;
  strlcpy(t->name, name, sizeof t->name);
  t->stack = (uint8_t*)t + PGSIZE;
  t->priority = priority;
#ifdef USERPROG
  t->pcb = NULL;
#endif
  t->magic = THREAD_MAGIC;
  t->original_priority = priority;
  list_init(&t->locks);
  t->lock_waiting = NULL;
  t->ticks = 0;

  if (is_hierarchy) {
    t->nice = 0;
  } else {
    if (priority == 56) {
      t->nice = 0;
    } else if (priority == 48) {
      t->nice = 1;
    } else if (priority == 40) {
      t->nice = 2;
    } else if (priority == 32) {
      t->nice = 3;
    } else if (priority == 24) {
      t->nice = 4;
    } else if (priority == 16) {
      t->nice = 5;
    } else if (priority == 8) {
      t->nice = 6;
    } else if (priority == 0) {
      t->nice = 7;
    }
  }
  t->recent_cpu = FP_CONST(0);

  old_level = intr_disable();
  list_insert_ordered(&all_list, &t->allelem, (list_less_func*)&compare_thread_priority, NULL);
  intr_set_level(old_level);
}

/*在线程 T 的栈顶分配一个 SIZE 字节的帧，返回指向帧基址的指针。*/
static void* alloc_frame(struct thread* t, size_t size) {
  /* Stack data is always allocated in word-size units. */
  ASSERT(is_thread(t));
  ASSERT(size % sizeof(uint32_t) == 0);

  t->stack -= size;
  return t->stack;
}

/*优先级调度器*/
static struct thread* thread_schedule_prio(void) {
  if (!list_empty(&new_ready_list))
    return list_entry(list_pop_front(&new_ready_list), struct thread, elem);
  else
    return idle_thread;
}

/*先入先出调度*/
static struct thread* thread_schedule_fifo(void) {
  if (!list_empty(&new_ready_list))
    return list_entry(list_pop_front(&new_ready_list), struct thread, elem);
  else
    return idle_thread;
}

/*不是实际的调度策略 — 空白的占位符 调度器跳转表中的插槽。*/
static struct thread* thread_schedule_reserved(void) {
  if (!list_empty(&new_ready_list))
    return list_entry(list_pop_front(&new_ready_list), struct thread, elem);
  else
    return idle_thread;
}

/*公平优先级调度*/
static struct thread* thread_schedule_fair(void) {
  if (!list_empty(&new_ready_list))
    return list_entry(list_pop_front(&new_ready_list), struct thread, elem);
  else
    return idle_thread;
}

/*多级反馈队列调度*/
static struct thread* thread_schedule_mlfqs(void) {
  if (!list_empty(&new_ready_list))
    return list_entry(list_pop_front(&new_ready_list), struct thread, elem);
  else
    return idle_thread;
}

/* Chooses and returns the next thread to be scheduled.  Should
   return a thread from the run queue, unless the run queue is
   empty.  (If the running thread can continue running, then it
   will be in the run queue.)  If the run queue is empty, return
   idle_thread. */
static struct thread* next_thread_to_run(void) {
  if (!list_empty(&new_ready_list))
    return list_entry(list_pop_front(&new_ready_list), struct thread, elem);
  else
    return idle_thread;
}

void thread_switch_tail(struct thread* prev) {
  struct thread* cur = running_thread();

  ASSERT(intr_get_level() == INTR_OFF);

  /* Mark us as running. */
  cur->status = THREAD_RUNNING;

  /* Start new time slice. */
  thread_ticks = 0;

#ifdef USERPROG
  /* Activate the new address space. */
  process_activate();
#endif

  /* If the thread we switched from is dying, destroy its struct
     thread.  This must happen late so that thread_exit() doesn't
     pull out the rug under itself.  (We don't free
     initial_thread because its memory was not obtained via
     palloc().) */
  if (prev != NULL && prev->status == THREAD_DYING && prev != initial_thread) {
    ASSERT(prev != cur);
    palloc_free_page(prev);
  }
}

/* Schedules a new thread.  At entry, interrupts must be off and
   the running process's state must have been changed from
   running to some other state.  This function finds another
   thread to run and switches to it.

   It's not safe to call printf() until thread_switch_tail()
   has completed. */
static void schedule(void) {
  struct thread* cur = running_thread();
  struct thread* next = next_thread_to_run();
  struct thread* prev = NULL;
  //msg("M%d--d%d--d%d",cur->priority,cur->nice,cur->original_priority);
  ASSERT(intr_get_level() == INTR_OFF);
  ASSERT(cur->status != THREAD_RUNNING);
  ASSERT(is_thread(next));

  if (cur != next)
    prev = switch_threads(cur, next);
  thread_switch_tail(prev);
}

/* 返回一个用于新线程的tid（线程ID）*/
static tid_t allocate_tid(void) {
  static tid_t next_tid = 1;
  tid_t tid;

  // 获取tid_lock锁，确保对next_tid的访问是原子的
  lock_acquire(&tid_lock);
  // 分配当前next_tid作为新线程的tid，并将next_tid自增
  tid = next_tid++;
  // 释放tid_lock锁
  lock_release(&tid_lock);

  return tid;
}

/* 检查被阻塞的线程，如果阻塞时间已到，则解除阻塞。 */
void blocked_thread_check(struct thread* t, void* aux UNUSED) {
  if (t->status == THREAD_BLOCKED && t->thread_sleepticks > 0) {
    t->thread_sleepticks--;
    if (t->thread_sleepticks == 0) {
      thread_unblock(t);
    }
  }
}

/* 用于比较两个线程优先级的函数 */
bool compare_thread_priority(const struct list_elem* a, const struct list_elem* b,
                             void* aux UNUSED) {
  return list_entry(a, struct thread, elem)->priority >
         list_entry(b, struct thread, elem)->priority;
}

/* 调整线程的优先级并重新插入到就绪队列中。 */
void thread_donate_priority(struct thread* t) {
  // 禁用中断，保存当前的中断级别到old_level中
  enum intr_level old_level = intr_disable();
  // 更新线程的优先级
  thread_update_priority(t);

  // 如果线程状态为THREAD_READY（就绪状态）
  if (t->status == THREAD_READY) {
    list_remove(&t->elem);
    list_insert_ordered(&new_ready_list, &t->elem, compare_thread_priority, NULL);
  }
  // 恢复之前保存的中断级别
  intr_set_level(old_level);
}

/* 线程持有（获取）一个锁。 */
void thread_hold_the_lock(struct lock* lock) {
  // 禁用中断，保存当前的中断级别到old_level中
  enum intr_level old_level = intr_disable();
  // 将锁按照优先级顺序插入到当前线程的锁列表中
  list_insert_ordered(&thread_current()->locks, &lock->elem, lock_cmp_priority, NULL);

  // 如果锁的优先级高于当前线程的优先级
  if (lock->max_priority > thread_current()->priority) {
    thread_current()->priority = lock->max_priority;
    thread_yield();
  }
  // 恢复之前保存的中断级别
  intr_set_level(old_level);
}

// 更新系统平均负载和近期CPU使用率
void mlfqs_update_load_avg_and_recent_cpu() {
  ASSERT(active_sched_policy == SCHED_FAIR);
  ASSERT(intr_context());

  // 获取就绪线程数
  size_t ready_cnt = list_size(&new_ready_list);
  if (thread_current() != idle_thread)
    ++ready_cnt;
  // 更新系统平均负载
  load_avg = FP_ADD(FP_DIV_MIX(FP_MULT_MIX(load_avg, 59), 60), FP_DIV_MIX(FP_CONST(ready_cnt), 60));

  struct thread* t;
  struct list_elem* e;
  // 遍历所有线程列表
  for (e = list_begin(&all_list); e != list_end(&all_list); e = list_next(e)) {
    t = list_entry(e, struct thread, allelem);
    if (t != idle_thread) {

      t->recent_cpu = FP_ADD_MIX(FP_MULT(FP_DIV(FP_MULT_2_F(load_avg, 1), \ 
                      FP_ADD_MIX(FP_MULT_2_F(load_avg, 1), 1)),
                                         t->recent_cpu),
                                 0);

      mlfqs_update_priority(t);
    }
  }
}

// 从锁列表中移除指定的锁
void thread_remove_lock(struct lock* lock) {
  // 禁用中断，以避免在操作过程中被打断
  enum intr_level old_level = intr_disable();
  list_remove(&lock->elem);
  thread_update_priority(thread_current());
  intr_set_level(old_level);
}

// 更新线程的优先级，根据其持有的锁的优先级来调整
void thread_update_priority(struct thread* t) {
  enum intr_level old_level = intr_disable();
  int max_priority = t->original_priority; // 初始化最大优先级为基本优先级
  int lock_priority;                       // 用于存储锁的优先级

  if (!list_empty(&t->locks)) {
    // 对锁列表进行排序，根据锁的最大优先级进行排序
    list_sort(&t->locks, lock_cmp_priority, NULL);
    lock_priority = list_entry(list_front(&t->locks), struct lock, elem)->max_priority;
    if (lock_priority > max_priority)
      max_priority = lock_priority;
  }

  // 设置线程的优先级为最大优先级值，并存储到线程结构体中
  t->priority = max_priority;
  intr_set_level(old_level);
}

/* 比较两个锁的优先级的函数，用于`list_sort`函数进行排序操作*/
bool lock_cmp_priority(const struct list_elem* a, const struct list_elem* b, void* aux UNUSED) {
  return list_entry(a, struct lock, elem)->max_priority >
         list_entry(b, struct lock, elem)->max_priority;
}

// 增加线程的近期CPU使用率计数器值，用于后续计算线程的优先级。此函数必须在中断上下文中调用。
void mlfqs_inc_recent_cpu() {
  ASSERT(active_sched_policy == SCHED_FAIR);
  ASSERT(intr_context());

  struct thread* cur = thread_current();
  if (cur == idle_thread)
    return;
  cur->recent_cpu = FP_ADD_MIX(cur->recent_cpu, 1);
}

// 更新线程的优先级
void mlfqs_update_priority(struct thread* t) {
  ASSERT(active_sched_policy == SCHED_FAIR);

  if (t == idle_thread)
    return;
  // 判断是否使用层次调度
  if (is_hierarchy) {
    t->priority = FP_INT_PART(FP_SUB_MIX(FP_SUB(FP_CONST(PRI_MAX), (FP_DIV_MIX(t->recent_cpu, 4))),t->nice));
  } else {
    t->priority = FP_INT_PART(FP_SUB_MIX(FP_SUB(FP_CONST(PRI_MAX), FP_DIV_MIX(t->recent_cpu, 4)), 0));
  }

  // 确保优先级在合法范围内
  if (t->priority < PRI_MIN)
    t->priority = PRI_MIN;
  else if (t->priority > PRI_MAX)
    t->priority = PRI_MAX;
}

// 更新线程的ticks值，并处理相应的调度行为
void thread_fair_update_ticks(void) {
  struct thread* current_thread = thread_current();
  if (current_thread == idle_thread)
    return;
  current_thread->ticks = current_thread->ticks + 1;
  if (current_thread->ticks >= current_thread->priority) { // 如果当前线程是空闲线程，则直接返回
    current_thread->ticks = 0;
    if (!intr_context())
      thread_yield();
    else
      intr_yield_on_return();
  }
}
/* Offset of `stack' member within `struct thread'.
   Used by switch.S, which can't figure it out on its own. */
uint32_t thread_stack_ofs = offsetof(struct thread, stack);
