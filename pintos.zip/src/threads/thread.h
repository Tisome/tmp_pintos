#ifndef THREADS_THREAD_H
#define THREADS_THREAD_H

#include <debug.h>
#include <list.h>
#include <stdint.h>
#include "threads/synch.h"
#include "threads/fixed-point.h"

//线程标识符类型定义
typedef int tid_t;
#define TID_ERROR ((tid_t)-1)

/*线程优先级定义*/
#define PRI_MIN 0
#define PRI_DEFAULT 31
#define PRI_MAX 63

enum thread_status { THREAD_RUNNING, THREAD_READY, THREAD_BLOCKED, THREAD_DYING };

/* A kernel thread or user process.

   Each thread structure is stored in its own 4 kB page.  The
   thread structure itself sits at the very bottom of the page
   (at offset 0).  The rest of the page is reserved for the
   thread's kernel stack, which grows downward from the top of
   the page (at offset 4 kB).  Here's an illustration:

        4 kB +---------------------------------+
             |          kernel stack           |
             |                |                |
             |                |                |
             |                V                |
             |         grows downward          |
             |                                 |
             |                                 |
             |                                 |
             |                                 |
             |                                 |
             |                                 |
             |                                 |
             |                                 |
             +---------------------------------+
             |              magic              |
             |                :                |
             |                :                |
             |               name              |
             |              status             |
        0 kB +---------------------------------+

   The upshot of this is twofold:

      1. First, `struct thread' must not be allowed to grow too
         big.  If it does, then there will not be enough room for
         the kernel stack.  Our base `struct thread' is only a
         few bytes in size.  It probably should stay well under 1
         kB.

      2. Second, kernel stacks must not be allowed to grow too
         large.  If a stack overflows, it will corrupt the thread
         state.  Thus, kernel functions should not allocate large
         structures or arrays as non-static local variables.  Use
         dynamic allocation with malloc() or palloc_get_page()
         instead.

   The first symptom of either of these problems will probably be
   an assertion failure in thread_current(), which checks that
   the `magic' member of the running thread's `struct thread' is
   set to THREAD_MAGIC.  Stack overflow will normally change this
   value, triggering the assertion. */
struct thread {
  /*线程结构体定义*/
  tid_t tid;
  enum thread_status status;
  char name[16];
  uint8_t* stack;
  int priority;
  struct list_elem allelem;
  int64_t thread_sleepticks;
  int ticks;
  int original_priority; // 基础优先级
  struct list locks;
  struct lock* lock_waiting; // 正在等待的锁
  int nice;                  // 线程的nice值，影响调度行为
  fixed_t recent_cpu;        // 最近CPU使用时间
  struct list_elem elem;     /*列表元素，用于各种线程队列*/

#ifdef USERPROG
  struct process* pcb; /*如果此线程是用户程序，则指向其进程控制块*/
#endif
  /*由thread.c管理*/
  unsigned magic; /*用于检测栈溢出*/
};

/*用户可以请求内核在运行时使用的调度程序类型枚举 */
enum sched_policy {
  SCHED_FIFO,
  SCHED_PRIO,
  SCHED_FAIR,
  SCHED_MLFQS,
};

#define SCHED_DEFAULT SCHED_FIFO

extern bool thread_mlfqs; // 标记是否使用MLFQS调度器
void thread_init(void);   // 线程初始化函数
void thread_tick(void);
void thread_print_stats(void);
void thread_start(void); // 启动线程的函数
extern enum sched_policy active_sched_policy;

// 定义线程函数类型，该函数接受一个void指针作为参数
typedef void thread_func(void* aux);

// 将当前线程阻塞
void thread_block(void);

// 创建一个新线程，返回线程ID
tid_t thread_create(const char* name, int priority, thread_func*, void*);

// 获取当前线程的名称
const char* thread_name(void);

// 解除线程的阻塞状态
void thread_unblock(struct thread*);

// 获取当前线程的指针
struct thread* thread_current(void);

// 让出当前线程的CPU使用权，让其他线程运行
void thread_yield(void);

// 定义一个操作，该操作会对线程进行某些操作，并传递辅助数据AUX
typedef void thread_action_func(struct thread* t, void* aux);

// 获取当前线程的ID
tid_t thread_tid(void);

// 退出当前线程，不返回任何值
void thread_exit(void) NO_RETURN;

// 对所有线程执行操作，每个线程的参数为辅助数据AUX
void thread_foreach(thread_action_func*, void*);

// 获取当前线程的nice值（影响调度优先级
int thread_get_nice(void);

// 获取当前线程的优先级
int thread_get_priority(void);

// 设置当前线程的优先级
void thread_set_priority(int);

// 设置当前线程的nice值（影响调度优先级）
void thread_set_nice(int);

// 获取负载平均值，可能是特定线程的或全局的
int thread_get_load_avg(void);

// 获取最近CPU使用时间，可能是特定线程的或全局的
int thread_get_recent_cpu(void);

// 持有某个锁，可能是为了等待或防止其他线程获取该锁
void thread_hold_the_lock(struct lock* lock);

// 释放之前持有的锁，允许其他线程获取该锁
void thread_remove_lock(struct lock* lock);

// 更新线程的优先级或相关调度信息（由特定的函数决定）
void thread_update_priority(struct thread* t);

// 检查阻塞的线程是否满足某些条件（由特定的函数决定
void blocked_thread_check(struct thread* t, void* aux UNUSED);

// 比较两个线程或锁元素的优先级（由特定的函数决定）
bool compare_thread_priority(const struct list_elem* a, const struct list_elem* b,
                             void* aux UNUSED);

// 提高线程的优先级，可能是为了实现某种调度策略（如多级反馈队列）
void thread_donate_priority(struct thread* t);

// 根据多级反馈队列调度器（MLFQS）策略更新线程的优先级
void mlfqs_update_priority(struct thread* t);

// 比较两个锁元素的优先级（由特定的函数决定）
bool lock_cmp_priority(const struct list_elem* a, const struct list_elem* b, void* aux UNUSED);

// 增加最近CPU使用时间，可能是为了实现多级反馈队列调度器（MLFQS）策略的一部分
void mlfqs_inc_recent_cpu();

// 更新负载平均值和最近CPU使用时间，可能是为了实现多级反馈队列调度器（MLFQS）策略的一部分
void mlfqs_update_load_avg_and_recent_cpu();

// 更新线程的ticks值，可能是为了实现某种公平调度策略。
void thread_fair_update_ticks(void);
#endif /* threads/thread.h */
