#ifndef THREADS_SYNCH_H
#define THREADS_SYNCH_H

#include <list.h>
#include <stdbool.h>

struct semaphore {
  unsigned value;      /*当前值*/
  struct list waiters; /*等待线程列表*/
};

/*初始化信号量*/
void sema_init(struct semaphore*, unsigned value);

/*获取信号量（阻塞调用）*/
void sema_down(struct semaphore*);

/*尝试获取信号量（非阻塞调用）*/
bool sema_try_down(struct semaphore*);

/*释放信号量*/
void sema_up(struct semaphore*);

void sema_self_test(void);

struct lock {
  struct thread* holder;      /*持有锁的线程*/
  struct semaphore semaphore; /*控制访问的二进制信号量*/
  struct list_elem elem;      /*优先级捐赠列表元素*/
  int max_priority;
};

/*初始化锁 */
void lock_init(struct lock*);

/*释放锁*/
void lock_release(struct lock*);

/*尝试获取锁（非阻塞调用）*/
bool lock_try_acquire(struct lock*);

/*获取锁（阻塞调用）*/
void lock_acquire(struct lock*);

/*检查当前线程是否持有该锁*/
bool lock_held_by_current_thread(const struct lock*);

/*这是一个条件变量结构，用于实现线程之间的同步。它包含一个等待线程列表*/
struct condition {
  struct list waiters; /*等待线程列表*/
};

/*初始化条件变量*/
void cond_init(struct condition*);

/*发送信号通知等待条件变量的线程*/
void cond_signal(struct condition*, struct lock*);

/*广播信号通知所有等待条件变量的线程*/
void cond_broadcast(struct condition*, struct lock*);

/*等待条件变量（在给定的锁上）*/
void cond_wait(struct condition*, struct lock*);

/*比较两个列表元素和优先级捐赠的函数，用于确定哪个线程应该继续执行*/
bool cond_sema_cmp_priority(const struct list_elem* a, const struct list_elem* b, void* aux);

#define RW_READER 1 /*表示读锁*/
#define RW_WRITER 0 /*表示写锁*/

struct rw_lock {
  struct lock lock;       //控制访问的锁
  struct condition read;  //读等待条件变量
  struct condition write; //写等待条件变量
  int AR, WR, AW, WW;     //读写锁的内部状态变量
};

/*初始化读写锁*/
void rw_lock_init(struct rw_lock*);

/*释放读锁或写锁*/
void rw_lock_release(struct rw_lock*, bool reader);

/*获取读锁或写锁*/
void rw_lock_acquire(struct rw_lock*, bool reader);

/*优化屏障
这个宏用于阻止编译器对跨越优化屏障的代码进行重新排序。有关更多信息，请参阅参考指南中的“优化屏障”部分*/
#define barrier()                                                                                  \
  asm volatile(                                                                                    \
      ""                                                                                           \
      :                                                                                            \
      :                                                                                            \
      : "memory") 

#endif /* threads/synch.h */
